from flask import Flask, render_template, request
import requests
from pyswip import Prolog

app = Flask(__name__)

NASA_KEY = "DEMO_KEY"

prolog_engine = Prolog()
prolog_engine.consult("logic.pl")

@app.route("/", methods=["GET", "POST"])
def main():
    nasa_info = None
    ai_feedback = None

    if request.method == "POST":
        user_topic = request.form.get("topic", "").lower()
        resp = requests.get(f"https://api.nasa.gov/planetary/apod?api_key={NASA_KEY}")

        if resp.status_code == 200:
            info = resp.json()
            nasa_info = {
                "title": info.get("title"),
                "image": info.get("url"),
                "description": info.get("explanation")
            }

        query = list(prolog_engine.query(f"interesting({user_topic})"))
        ai_feedback = "AI finds this topic interesting!" if query else "AI has no information on this topic."

    return render_template("index.html", data=nasa_info, logic_result=ai_feedback)

if __name__ == "__main__":
    app.run(debug=True)