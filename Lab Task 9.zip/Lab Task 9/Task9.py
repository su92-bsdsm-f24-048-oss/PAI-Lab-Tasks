import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')

text = "Natural Language Processing helps computers understand human language efficiently."

words = word_tokenize(text)

print("Tokenized Words:")
print(words)

stop_words = set(stopwords.words('english'))

filtered_words = []

for word in words:
    if word.lower() not in stop_words:
        filtered_words.append(word)

print("\nWords after Stop Word Removal:")
print(filtered_words)