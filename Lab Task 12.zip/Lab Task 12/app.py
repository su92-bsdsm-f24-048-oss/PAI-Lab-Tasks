from flask import Flask, request, render_template
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import re

app = Flask(__name__, template_folder="templates")

qa_data = [
    {"question": "What is NLP?", "answer": "NLP helps computers understand human language."},
    {"question": "What is AI?", "answer": "AI is the simulation of human intelligence in machines."},
    {"question": "What is FAISS?", "answer": "FAISS is a library for fast similarity search."},
    {"question": "What is embedding?", "answer": "Embedding converts text into numerical vectors."},
    {"question": "What is Word2Vec?", "answer": "Word2Vec creates vector representations of words."}
]

def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)
    return text

questions = [clean_text(item["question"]) for item in qa_data]
answers = [item["answer"] for item in qa_data]

model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

question_embeddings = model.encode(questions)

question_embeddings = np.array(question_embeddings).astype("float32")

dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(question_embeddings)

def get_answer(query):
    query = clean_text(query)
    query_vec = model.encode([query])
    query_vec = np.array(query_vec).astype("float32")

    distances, indices = index.search(query_vec, 1)

    idx = indices[0][0]

    if idx < 0 or idx >= len(answers):
        return "No matching answer found."

    return answers[idx]

@app.route("/", methods=["GET", "POST"])
def home():
    response = ""

    if request.method == "POST":
        user_question = request.form["question"]
        response = get_answer(user_question)

    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)