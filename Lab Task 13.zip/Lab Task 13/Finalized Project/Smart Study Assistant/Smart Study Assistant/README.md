# StudyMind AI — Smart Study Assistant
### Programming for AI | 4th Semester Project

---

## Project Overview

**StudyMind AI** is a Flask-based AI-assisted study application that combines **NLP-based question classification** with **Generative AI** to provide structured, level-appropriate explanations for any academic question. Students can ask questions in natural language, receive detailed answers, and test themselves with AI-generated quizzes.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend Framework | Flask (Python) |
| NLP Classifier | Custom TF-IDF + Keyword Model |
| AI Engine | Anthropic Claude API (GenAI) |
| Frontend | HTML5, CSS3, Vanilla JS |
| Data | CSV Dataset (40+ labeled questions) |

---

## Project Structure

```
smart_study_assistant/
│
├── app.py                    # Main Flask application & API routes
├── requirements.txt          # Python dependencies
├── README.md                 # Project documentation
│
├── utils/
│   ├── __init__.py
│   ├── classifier.py         # NLP Question Classifier (TF-IDF + keyword matching)
│   ├── explainer.py          # AI Explanation Generator (Claude API)
│   └── quiz_generator.py     # AI Quiz Generator (Claude API)
│
├── templates/
│   └── index.html            # Full frontend (single-page app)
│
└── data/
    └── questions_dataset.csv # Labeled dataset for classifier training/reference
```

---

## Features

### 1. NLP Question Classifier (`utils/classifier.py`)
- Custom-built classifier using **TF-IDF-inspired keyword scoring**
- Classifies questions into **8 subjects**: Mathematics, Physics, Chemistry, Biology, Computer Science, History, Literature, Economics
- Identifies **subcategory** (e.g., Algebra, Organic Chemistry, Algorithms)
- Detects **difficulty level**: Beginner / Intermediate / Advanced
- Reports **confidence score** (50–100%)
- Supports **subject filtering** by user preference

### 2. AI Explanation Generator (`utils/explainer.py`)
- Calls **Anthropic Claude API** to generate structured explanations
- Returns JSON with: answer, step-by-step explanation, key concepts, examples, study tips, related topics, formulas
- Adapts content to user's **learning level** (beginner/intermediate/advanced)
- Includes **graceful fallback** if API is unavailable

### 3. AI Quiz Generator (`utils/quiz_generator.py`)
- Generates **multiple-choice quizzes** on any topic using Claude
- Returns 5–10 questions with 4 options each
- Includes **explanations** for correct answers
- Tracks **score** and session statistics

### 4. Flask REST API (`app.py`)
- `POST /api/ask` — Classify question + generate explanation
- `POST /api/quiz` — Generate quiz for a topic
- `GET /api/history` — Retrieve session question history
- `GET /api/subjects` — List available subjects
- `GET /api/tip_of_day` — Random study tip

### 5. Frontend (Single Page App)
- **Ask Mode**: Type questions, see classified + explained answers
- **Quiz Mode**: Generate and take AI-powered quizzes
- **Session Statistics**: Track questions asked, quizzes taken, best score
- **Level Selector**: Beginner / Intermediate / Advanced
- **Subject Filter**: Filter by specific academic subject
- **History Panel**: Click to re-ask previous questions

---

## Installation & Setup

### Prerequisites
- Python 3.9+
- An Anthropic API key (get one at https://console.anthropic.com)

### Steps

```bash
# 1. Navigate to project directory
cd smart_study_assistant

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate       # macOS/Linux
venv\Scripts\activate          # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set your Anthropic API key
# The API key is handled by the Anthropic API infrastructure.
# For local dev, set it as an environment variable:
export ANTHROPIC_API_KEY="your-key-here"

# 5. Run the application
python app.py

# 6. Open in browser
# Visit: http://localhost:5000
```

---

## How the NLP Classifier Works

The classifier uses a **multi-layer scoring approach**:

1. **Text Preprocessing**: Lowercasing, punctuation removal, stop-word filtering
2. **Keyword Scoring**: Each category and subcategory has a curated keyword list. Phrase matches score 2x vs single-word matches.
3. **Subject Hint Boost**: If user selects a subject, it gets +3 score bonus
4. **Confidence Normalization**: Final score is scaled to 50–100% range
5. **Difficulty Detection**: Pattern matching for question phrasing + word count heuristics

### Example Classification
```
Input: "How do you find the derivative of x²?"
→ Category: Mathematics (score: 4.0)
→ Subcategory: Calculus (keyword: "derivative")
→ Difficulty: intermediate (pattern: "how do you")
→ Confidence: 87%
```

---

## API Response Format

### POST /api/ask
```json
{
  "question": "What is Newton's second law?",
  "category": "Physics",
  "subcategory": "Mechanics",
  "confidence": 0.91,
  "difficulty": "beginner",
  "emoji": "⚡",
  "answer": "Newton's second law states that F = ma...",
  "explanation": "Step-by-step breakdown...",
  "key_concepts": ["Force", "Mass", "Acceleration"],
  "examples": ["A heavier object needs more force to accelerate"],
  "tips": ["Remember F=ma", "Draw free body diagrams"],
  "related_topics": ["Newton's First Law", "Momentum", "Work-Energy Theorem"],
  "formula": "F = ma",
  "timestamp": "14:32"
}
```

---

## Dataset

The dataset (`data/questions_dataset.csv`) contains **40+ labeled questions** across all subjects with columns:
- `question`: The academic question text
- `category`: Subject (Mathematics, Physics, etc.)
- `subcategory`: Specific topic (Algebra, Mechanics, etc.)
- `difficulty`: beginner / intermediate / advanced

This dataset is used to validate and refine the classifier's keyword lists.

---

## Team / Credits
- **Project Type**: Programming for AI — 4th Semester
- **Approach**: NLP + GenAI + Flask
- **Model**: Anthropic Claude (claude-sonnet-4-20250514)

---

## Future Enhancements
- [ ] Train a proper ML classifier (Naive Bayes / SVM) on larger dataset
- [ ] Add PDF/image question input (OCR)
- [ ] Student progress tracking with database
- [ ] Multi-language support
- [ ] Voice input/output
