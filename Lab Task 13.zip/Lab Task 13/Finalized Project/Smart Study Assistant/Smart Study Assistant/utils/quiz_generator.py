import json
import requests
import re

class QuizGenerator:

    def __init__(self):
        self.api_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
        self.api_key = "AIzaSyACxUcGJSybKT6zytdcLiYycVEphZtrEOU"

    def generate(self, topic, category, count=5):
        if not topic:
            topic = category
        prompt = "You are an educational quiz creator. Generate " + str(count) + " multiple choice questions about: " + topic + " Respond ONLY with a valid JSON array. Format: [{\"question\": \"Q?\", \"options\": [\"A\", \"B\", \"C\", \"D\"], \"correct\": 0, \"explanation\": \"Why.\"}]"
        try:
            response = requests.post(
                self.api_url,
                headers={"Content-Type": "application/json", "X-goog-api-key": self.api_key},
                json={"contents": [{"parts": [{"text": prompt}]}]}
            )
            raw = response.json()["candidates"][0]["content"]["parts"][0]["text"]
            raw = re.sub(r"^```(?:json)?\s*", "", raw.strip())
            raw = re.sub(r"\s*```$", "", raw)
            return json.loads(raw)[:count]
        except Exception as e:
            print("QUIZ ERROR:", e)
            return self._fallback_quiz(topic)

    def _fallback_quiz(self, topic):
        return [{"question": "What is a key concept in " + topic + "?", "options": ["A fundamental principle", "A random fact", "An outdated theory", "An abstract idea"], "correct": 0, "explanation": "Core concepts are foundational."}]
