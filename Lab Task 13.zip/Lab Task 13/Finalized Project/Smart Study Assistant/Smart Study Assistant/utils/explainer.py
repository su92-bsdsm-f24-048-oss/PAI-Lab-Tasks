import json
import requests
import re

class ExplanationGenerator:

    def __init__(self):
        self.api_url = "https://api.groq.com/openai/v1/chat/completions"
        self.api_key = "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"

    def generate(self, question, category, subcategory, level="intermediate"):
        system = "You are StudyMind AI expert tutor in " + category + ". Respond ONLY with JSON: {\"answer\": \"text\", \"explanation\": \"text\", \"key_concepts\": [\"c1\"], \"examples\": [\"e1\"], \"tips\": [\"t1\"], \"related_topics\": [\"r1\"], \"formula\": null}"
        try:
            r = requests.post(self.api_url, headers={"Authorization": "Bearer " + self.api_key, "Content-Type": "application/json"}, json={"model": "llama-3.3-70b-versatile", "messages": [{"role": "system", "content": system}, {"role": "user", "content": question}]})
            print("STATUS:", r.status_code)
            raw = r.json()["choices"][0]["message"]["content"]
            raw = re.sub(r"^`(?:json)?\s*", "", raw.strip())
            raw = re.sub(r"\s*`$", "", raw).strip()
            data = json.loads(raw)
            return {"answer": data.get("answer",""), "explanation": data.get("explanation",""), "key_concepts": data.get("key_concepts",[]), "examples": data.get("examples",[]), "tips": data.get("tips",[]), "related_topics": data.get("related_topics",[]), "formula": data.get("formula",None)}
        except Exception as e:
            print("ERROR:", e)
            return {"answer": "Error: " + str(e), "explanation": "", "key_concepts": [], "examples": [], "tips": [], "related_topics": [], "formula": None}
