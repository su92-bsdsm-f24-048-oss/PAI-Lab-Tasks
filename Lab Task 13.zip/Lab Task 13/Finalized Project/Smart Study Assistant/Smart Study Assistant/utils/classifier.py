import re
import json
import math
from collections import defaultdict

class QuestionClassifier:
    """
    NLP-based question classifier using TF-IDF and keyword matching.
    Classifies questions into subjects, categories, and difficulty levels.
    """
    
    def __init__(self):
        self.categories = self._build_category_map()
        self.stop_words = {
            "what", "is", "are", "how", "why", "when", "where", "who",
            "does", "do", "the", "a", "an", "in", "on", "at", "to",
            "of", "and", "or", "but", "if", "then", "can", "could",
            "would", "should", "will", "be", "been", "being", "have",
            "has", "had", "this", "that", "these", "those", "it", "its"
        }
        self.difficulty_patterns = self._build_difficulty_patterns()

    def _build_category_map(self):
        return {
            "Mathematics": {
                "emoji": "➕",
                "subcategories": {
                    "Algebra": ["equation", "variable", "solve", "polynomial", "linear", "quadratic", "factor", "simplify", "expression", "algebra", "coefficient", "matrix", "determinant", "system"],
                    "Calculus": ["derivative", "integral", "differentiate", "integrate", "limit", "continuity", "rate of change", "slope", "area under", "differential", "antiderivative", "chain rule", "product rule"],
                    "Geometry": ["triangle", "circle", "area", "perimeter", "volume", "angle", "polygon", "coordinate", "geometry", "hypotenuse", "radius", "diameter", "tangent", "chord", "arc"],
                    "Statistics": ["mean", "median", "mode", "probability", "distribution", "standard deviation", "variance", "regression", "correlation", "hypothesis", "sample", "population", "normal distribution"],
                    "Number Theory": ["prime", "factorial", "integer", "divisible", "lcm", "gcd", "modulo", "arithmetic", "number", "odd", "even", "digit", "sequence", "series"],
                }
            },
            "Physics": {
                "emoji": "⚡",
                "subcategories": {
                    "Mechanics": ["force", "motion", "velocity", "acceleration", "momentum", "energy", "work", "power", "gravity", "friction", "torque", "newton", "kinematics", "mass", "weight"],
                    "Electricity": ["current", "voltage", "resistance", "circuit", "capacitor", "inductor", "electric field", "magnetic field", "ohm", "ampere", "conductor", "semiconductor", "charge", "potential"],
                    "Optics": ["light", "reflection", "refraction", "lens", "mirror", "wavelength", "frequency", "spectrum", "diffraction", "interference", "polarization", "photon", "optics"],
                    "Thermodynamics": ["temperature", "heat", "entropy", "thermodynamics", "pressure", "volume", "gas", "ideal gas", "kelvin", "celsius", "thermal", "conduction", "convection", "radiation"],
                    "Quantum": ["quantum", "wave function", "photon", "electron", "orbital", "uncertainty", "superposition", "entanglement", "planck", "bohr", "atom", "nuclear", "radioactive"],
                }
            },
            "Chemistry": {
                "emoji": "🧪",
                "subcategories": {
                    "Organic Chemistry": ["carbon", "hydrocarbon", "alkane", "alkene", "alcohol", "acid", "ester", "benzene", "organic", "functional group", "isomer", "polymer", "reaction mechanism"],
                    "Inorganic Chemistry": ["metal", "nonmetal", "salt", "oxide", "periodic table", "element", "compound", "ion", "ionic", "covalent", "bonding", "electronegativity", "oxidation"],
                    "Physical Chemistry": ["equilibrium", "rate", "kinetics", "thermochemistry", "enthalpy", "entropy", "gibbs", "electrochemistry", "cell potential", "ph", "buffer", "titration"],
                    "Stoichiometry": ["mole", "molarity", "concentration", "stoichiometry", "yield", "limiting reagent", "balanced equation", "molecular weight", "empirical formula"],
                }
            },
            "Biology": {
                "emoji": "🧬",
                "subcategories": {
                    "Cell Biology": ["cell", "membrane", "organelle", "mitochondria", "nucleus", "cytoplasm", "dna", "rna", "protein", "enzyme", "atp", "mitosis", "meiosis", "chromosome"],
                    "Genetics": ["gene", "genetics", "heredity", "trait", "allele", "genotype", "phenotype", "dominant", "recessive", "mutation", "dna", "rna", "transcription", "translation", "mendel"],
                    "Ecology": ["ecosystem", "food chain", "biome", "population", "community", "habitat", "predator", "prey", "symbiosis", "biodiversity", "adaptation", "evolution", "natural selection"],
                    "Human Biology": ["heart", "lung", "brain", "blood", "immune", "digestion", "nervous system", "hormone", "muscle", "bone", "organ", "tissue", "respiration", "circulation"],
                }
            },
            "Computer Science": {
                "emoji": "💻",
                "subcategories": {
                    "Algorithms": ["algorithm", "sorting", "searching", "complexity", "big o", "recursion", "dynamic programming", "greedy", "divide and conquer", "binary search", "time complexity", "space complexity"],
                    "Data Structures": ["array", "linked list", "stack", "queue", "tree", "graph", "hash", "heap", "data structure", "node", "pointer", "binary tree", "balanced tree"],
                    "Programming": ["code", "function", "loop", "variable", "class", "object", "inheritance", "polymorphism", "debug", "syntax", "compile", "runtime", "python", "java", "javascript", "c++"],
                    "Networking": ["network", "protocol", "tcp", "ip", "http", "dns", "router", "packet", "bandwidth", "latency", "firewall", "encryption", "ssl", "vpn", "socket"],
                    "AI/ML": ["machine learning", "neural network", "deep learning", "training", "model", "dataset", "classification", "regression", "clustering", "gradient descent", "backpropagation", "ai", "artificial intelligence"],
                }
            },
            "History": {
                "emoji": "📜",
                "subcategories": {
                    "World Wars": ["world war", "wwi", "wwii", "nazi", "holocaust", "trench", "treaty", "allies", "axis", "hiroshima", "d-day", "pearl harbor", "1914", "1939", "1945"],
                    "Ancient History": ["ancient", "egypt", "roman", "greek", "mesopotamia", "civilization", "empire", "pharaoh", "julius caesar", "alexander", "athens", "rome", "bc", "bce"],
                    "Modern History": ["revolution", "industrial", "colonial", "independence", "cold war", "democracy", "communism", "capitalism", "19th century", "20th century", "civil rights"],
                }
            },
            "Literature": {
                "emoji": "📚",
                "subcategories": {
                    "Literary Devices": ["metaphor", "simile", "alliteration", "symbolism", "irony", "foreshadowing", "theme", "motif", "allegory", "hyperbole", "personification", "imagery", "tone", "mood"],
                    "Poetry": ["poem", "stanza", "rhyme", "meter", "sonnet", "verse", "lyric", "epic", "ode", "ballad", "iambic", "pentameter", "haiku"],
                    "Fiction Analysis": ["character", "plot", "setting", "conflict", "resolution", "protagonist", "antagonist", "narrative", "point of view", "climax", "denouement"],
                }
            },
            "Economics": {
                "emoji": "📈",
                "subcategories": {
                    "Microeconomics": ["supply", "demand", "market", "price", "consumer", "producer", "elasticity", "marginal", "utility", "competition", "monopoly", "oligopoly"],
                    "Macroeconomics": ["gdp", "inflation", "unemployment", "fiscal", "monetary", "interest rate", "recession", "growth", "trade", "balance of payments", "exchange rate"],
                }
            }
        }

    def _build_difficulty_patterns(self):
        return {
            "beginner": ["what is", "define", "explain", "describe", "basic", "simple", "introduction", "what does", "meaning of"],
            "intermediate": ["how does", "why does", "calculate", "solve", "difference between", "compare", "analyze", "explain how"],
            "advanced": ["derive", "prove", "evaluate", "critically", "advanced", "complex", "optimization", "theoretical", "synthesis"]
        }

    def preprocess(self, text):
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        tokens = text.split()
        return [t for t in tokens if t not in self.stop_words and len(t) > 2]

    def classify(self, question, subject_hint="auto"):
        q_lower = question.lower()
        tokens = self.preprocess(question)
        
        scores = defaultdict(float)
        subcat_scores = defaultdict(lambda: defaultdict(float))

        for category, data in self.categories.items():
            for subcategory, keywords in data["subcategories"].items():
                for keyword in keywords:
                    if keyword in q_lower:
                        # Phrase match scores higher
                        weight = 2.0 if " " in keyword else 1.0
                        scores[category] += weight
                        subcat_scores[category][subcategory] += weight

        # Apply subject hint
        if subject_hint != "auto" and subject_hint in self.categories:
            scores[subject_hint] += 3.0

        if not scores:
            return {
                "category": "General",
                "subcategory": "General Knowledge",
                "confidence": 0.45,
                "difficulty": self._detect_difficulty(question),
                "emoji": "🎓"
            }

        best_cat = max(scores, key=scores.get)
        total_score = sum(scores.values())
        confidence = min(scores[best_cat] / max(total_score, 1), 1.0)
        confidence = 0.5 + confidence * 0.5  # Scale to 50-100%

        best_subcat = "General"
        if subcat_scores[best_cat]:
            best_subcat = max(subcat_scores[best_cat], key=subcat_scores[best_cat].get)

        return {
            "category": best_cat,
            "subcategory": best_subcat,
            "confidence": round(confidence, 2),
            "difficulty": self._detect_difficulty(question),
            "emoji": self.categories[best_cat]["emoji"]
        }

    def _detect_difficulty(self, question):
        q_lower = question.lower()
        for level, patterns in self.difficulty_patterns.items():
            for pattern in patterns:
                if pattern in q_lower:
                    return level
        # Word count heuristic
        words = question.split()
        if len(words) < 6:
            return "beginner"
        elif len(words) < 15:
            return "intermediate"
        return "advanced"

    def get_all_subjects(self):
        return [
            {"name": name, "emoji": data["emoji"]}
            for name, data in self.categories.items()
        ]
