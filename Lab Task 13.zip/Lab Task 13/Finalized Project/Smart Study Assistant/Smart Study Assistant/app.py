import os
from dotenv import load_dotenv

load_dotenv()  

import json
import re
import random
from flask import Flask, render_template, request, jsonify, session
from utils.classifier import QuestionClassifier
from utils.explainer import ExplanationGenerator
from utils.quiz_generator import QuizGenerator
from datetime import datetime

app = Flask(__name__)
app.secret_key = "smartstudy_secret_2024"

classifier = QuestionClassifier()
explainer = ExplanationGenerator()
quiz_gen = QuizGenerator()

@app.route("/")
def index():
    if "history" not in session:
        session["history"] = []
    return render_template("index.html")

@app.route("/api/ask", methods=["POST"])
def ask():
    data = request.get_json()
    question = data.get("question", "").strip()
    subject = data.get("subject", "auto")
    level = data.get("level", "intermediate")

    if not question:
        return jsonify({"error": "No question provided"}), 400


    classification = classifier.classify(question, subject)

    explanation = explainer.generate(
        question=question,
        category=classification["category"],
        subcategory=classification["subcategory"],
        level=level
    )


    result = {
        "question": question,
        "category": classification["category"],
        "subcategory": classification["subcategory"],
        "confidence": classification["confidence"],
        "difficulty": classification["difficulty"],
        "answer": explanation["answer"],
        "explanation": explanation["explanation"],
        "key_concepts": explanation["key_concepts"],
        "examples": explanation["examples"],
        "tips": explanation["tips"],
        "related_topics": explanation["related_topics"],
        "formula": explanation.get("formula", None),
        "timestamp": datetime.now().strftime("%H:%M"),
        "emoji": classification["emoji"]
    }

    # Save to session history
    history = session.get("history", [])
    history.append({
        "question": question,
        "category": result["category"],
        "timestamp": result["timestamp"]
    })
    session["history"] = history[-10:]  

    return jsonify(result)

@app.route("/api/quiz", methods=["POST"])
def generate_quiz():
    data = request.get_json()
    topic = data.get("topic", "")
    category = data.get("category", "Science")
    count = min(int(data.get("count", 5)), 10)

    quiz = quiz_gen.generate(topic=topic, category=category, count=count)
    return jsonify({"quiz": quiz})

@app.route("/api/history", methods=["GET"])
def get_history():
    return jsonify({"history": session.get("history", [])})

@app.route("/api/subjects", methods=["GET"])
def get_subjects():
    subjects = classifier.get_all_subjects()
    return jsonify({"subjects": subjects})

@app.route("/api/tip_of_day", methods=["GET"])
def tip_of_day():
    tips = [
        {"tip": "Use the Feynman Technique: explain concepts in simple terms as if teaching a child.", "emoji": "🧠"},
        {"tip": "Space repetition beats cramming. Review material at increasing intervals.", "emoji": "📅"},
        {"tip": "Active recall is 3x more effective than passive re-reading.", "emoji": "💡"},
        {"tip": "The Pomodoro method: 25 minutes focus, 5 minute break, repeat.", "emoji": "🍅"},
        {"tip": "Mind maps connect ideas visually and boost retention by 30%.", "emoji": "🗺️"},
        {"tip": "Teach what you learn. Explaining to others solidifies your understanding.", "emoji": "🎓"},
        {"tip": "Sleep is when memory consolidation happens. Don't sacrifice it for study.", "emoji": "😴"},
    ]
    return jsonify(random.choice(tips))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
