﻿import requests
r = requests.post(
    'https://api.groq.com/openai/v1/chat/completions',
    headers={
        'Authorization': 'Bearer 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',
        'Content-Type': 'application/json'
    },
    json={
        'model': 'llama3-8b-8192',
        'messages': [{'role': 'user', 'content': 'say hello'}]
    }
)
print(r.status_code)
print(r.json())
