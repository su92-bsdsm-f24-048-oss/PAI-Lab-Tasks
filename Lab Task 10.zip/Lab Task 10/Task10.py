from gensim.models import Word2Vec

sentences = [
    ["king", "queen", "royal", "crown", "throne"],
    ["man", "woman", "human", "person", "people"],
    ["paris", "france", "europe", "city", "capital"],
    ["berlin", "germany", "europe", "capital", "city"],
    ["prince", "princess", "royal", "kingdom"],
    ["boy", "girl", "child", "human"],
    ["apple", "banana", "fruit", "food"],
    ["car", "bus", "vehicle", "transport"]
]

model = Word2Vec(sentences, vector_size=50, window=3, min_count=1, workers=1)

print("Words most similar to 'king':")
print(model.wv.most_similar("king"))