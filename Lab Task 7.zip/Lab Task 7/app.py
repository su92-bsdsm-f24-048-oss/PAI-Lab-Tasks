from flask import Flask, jsonify
import requests

app = Flask(__name__)

@app.route('/joke', methods=['GET'])
def get_joke():
    try:
        response = requests.get("https://v2.jokeapi.dev/joke/Any")
        data = response.json()

        if data['type'] == 'single':
            joke = data['joke']
        else:
            joke = f"{data['setup']} ... {data['delivery']}"

        return jsonify({"joke": joke})

    except Exception as e:
        return jsonify({"error": "Failed to fetch joke", "details": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)