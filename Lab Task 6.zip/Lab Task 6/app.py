import os
from flask import Flask, render_template, request, redirect, url_for
import cv2

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 
                                     "haarcascade_frontalface_default.xml")

@app.route("/", methods=["GET", "POST"])
def index():
    detected_image = None

    if request.method == "POST":
        file = request.files["image"]
        if file:
            filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(filepath)

            img = cv2.imread(filepath)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

            faces = face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)

            result_path = os.path.join(app.config["UPLOAD_FOLDER"], "result.jpg")
            cv2.imwrite(result_path, img)

            detected_image = "uploads/result.jpg"

    return render_template("index.html", image=detected_image)

if __name__ == "__main__":
    app.run(debug=True)