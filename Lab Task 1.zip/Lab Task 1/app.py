from flask import Flask, render_template, request
import pandas as pd
from model import train_model, predict_result

app = Flask(__name__)

model = train_model()

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    study_hours = float(request.form["study_hours"])
    attendance = float(request.form["attendance"])
    assignments = float(request.form["assignments"])

    result = predict_result(model, study_hours, attendance, assignments)

    return render_template("index.html", prediction=result)


if __name__ == "__main__":
    app.run(debug=True)