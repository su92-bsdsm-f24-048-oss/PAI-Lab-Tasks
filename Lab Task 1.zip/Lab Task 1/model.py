import pandas as pd
from sklearn.tree import DecisionTreeClassifier


def train_model():

    df = pd.read_csv("student_data.csv")

    X = df[["study_hours", "attendance", "assignments"]]
    y = df["result"]

    model = DecisionTreeClassifier()
    model.fit(X, y)

    return model


def predict_result(model, study_hours, attendance, assignments):

    data = [[study_hours, attendance, assignments]]

    prediction = model.predict(data)

    if prediction[0] == 1:
        return "Pass"
    else:
        return "Fail"